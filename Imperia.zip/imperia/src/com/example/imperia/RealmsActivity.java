package com.example.imperia;

import java.util.ArrayList;
import java.util.List;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;


	
public class RealmsActivity extends Activity  {
	ListView lv;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_realms);
		
		lv = (ListView)findViewById(R.id.listView1);
		List<ListViewItem> items = new ArrayList<ListViewItem>();
		items.add(new ListViewItem()
		{{
			ThumbnailResource = R.drawable.realmtwo;
			Title = "Realm 1";
			SubTitle = "For beginners";
		}});
		items.add(new ListViewItem()
		{{
			ThumbnailResource = R.drawable.realmone;
			Title = "Realm 2";
			SubTitle = "For newbys";
		}});
		items.add(new ListViewItem()
		{{
			ThumbnailResource = R.drawable.realmthree;
			Title = "Realm 3";
			SubTitle = "Medium";
		}});
		items.add(new ListViewItem()
		{{
			ThumbnailResource = R.drawable.realmfour;
			Title = "Realm 4";
			SubTitle = "For confident players";
		}});
		items.add(new ListViewItem()
		{{
			ThumbnailResource = R.drawable.realmfive;
			Title = "Realm 5";
			SubTitle = "For experienced players";
		}});
		items.add(new ListViewItem()
		{{
			ThumbnailResource = R.drawable.realmsix;
			Title = "Realm 6";
			SubTitle = "This is gonna test your skillz";
		}});
		CustomListViewAdapter adapter = new CustomListViewAdapter(this, items);
		lv.setAdapter(adapter);
	}
	
	class ListViewItem{
		
		public int ThumbnailResource;
		public String Title;
		public String SubTitle;
	}
	


	public boolean checkRealm(int realmLevel){
		
		return true;
	}
	
	
}
