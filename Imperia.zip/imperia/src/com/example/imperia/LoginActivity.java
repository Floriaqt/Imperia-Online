package com.example.imperia;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class LoginActivity extends Activity implements OnClickListener {
	Button login;
	EditText username, password;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		
		setup();
	}


	private void setup() {
		username = (EditText) findViewById(R.id.username);
		password = (EditText) findViewById(R.id.password);
		login = (Button) findViewById(R.id.login);
		login.setOnClickListener(this);
	}


	@Override
	public void onClick(View arg0) {
		switch(arg0.getId()){
		
		case R.id.login:
			
			if(login()){
				startActivity(new Intent(LoginActivity.this, RealmsActivity.class));
			}
			
			break;
		}
		
	}


	private boolean login() {
	
		return true;
	}


}
